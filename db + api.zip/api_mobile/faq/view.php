<?php
include '../connection.php';

$sql = "SELECT * FROM faq";
$result = $connect->query($sql);

if($result->num_rows > 0) {
    $faq = array();
    while($row = $result->fetch_assoc()) {
        $faq[] = $row;
    }
    echo json_encode(array(
        "success" => true,
        "faq" => $faq,
    ));
} else {
    echo json_encode(array(
        "success" => false,
    ));
}
?>