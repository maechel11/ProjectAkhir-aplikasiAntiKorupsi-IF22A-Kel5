<?php

include 'connection.php';

$sql = "SELECT id, title, short_description, full_description FROM uud";
$result = $connect->query($sql);

$uud_list = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $uud_list[] = $row;
    }
}

$connect->close();

header('Content-Type: application/json');
echo json_encode($uud_list);

?>