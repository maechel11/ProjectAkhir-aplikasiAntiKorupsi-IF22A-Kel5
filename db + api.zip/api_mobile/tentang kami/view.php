<?php
include '../connection.php';

$sql = "SELECT * FROM tentangkami";
$result = $connect->query($sql);

if($result->num_rows > 0) {
    $tentangkami = array();
    while($row = $result->fetch_assoc()) {
        $tentangkami[] = $row;
    }
    echo json_encode(array(
        "success" => true,
        "tentangkami" => $tentangkami,
    ));
} else {
    echo json_encode(array(
        "success" => false,
    ));
}
?>