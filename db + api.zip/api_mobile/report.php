<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
include 'connection.php';

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
} 

// Get the POST data
$postData = file_get_contents('php://input');
$data = json_decode($postData, true);

// Check if data is received
if (!$data || !isset($data['name']) || !isset($data['phone']) || !isset($data['email']) || !isset($data['accusedName']) || !isset($data['accusedAddress']) || !isset($data['reportDescription'])) {
    http_response_code(400);
    echo json_encode(["message" => "Invalid input data"]);
    exit();
}

$name = $data['name'];
$phone = $data['phone'];
$email = $data['email'];

$accusedName = $data['accusedName'];
$accusedAddress = $data['accusedAddress'];
$reportDescription = $data['reportDescription'];

// Prepare and bind
$stmt = $connect->prepare("INSERT INTO reports (name, phone, email, accused_name, accused_address, report_description) VALUES (?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["message" => "Preparation failed: " . $connect->error]);
    exit();
}
$stmt->bind_param("ssssss", $name, $phone, $email, $accusedName, $accusedAddress, $reportDescription);

if ($stmt->execute()) {
    echo json_encode(["message" => "Report submitted successfully!"]);
} else {
    http_response_code(500);
    echo json_encode(["message" => "Execution failed: " . $stmt->error]);
}

$stmt->close();
$connect->close();
?>
