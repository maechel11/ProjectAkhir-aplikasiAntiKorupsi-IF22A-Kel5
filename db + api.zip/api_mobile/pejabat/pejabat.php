<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_mobile";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT id, nama, jabatan, kasus, foto FROM pejabat";
$result = $conn->query($sql);

$pejabat = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $pejabat[] = $row;
    }
}

echo json_encode($pejabat);

$conn->close();
?>