<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
include 'connection.php';

// Check if ID parameter is provided
if(isset($_POST['id'])) {
    // Prepare a delete statement
    $stmt = $connect->prepare("DELETE FROM reports WHERE id = ?");

    // Bind the parameter
    $stmt->bind_param("i", $_POST['id']);

    // Execute the statement
    if($stmt->execute()) {
        // Return success message
        echo json_encode(array("message" => "Report deleted successfully."));
    } else {
        // Return error message
        echo json_encode(array("message" => "Failed to delete report."));
    }

    // Close statement
    $stmt->close();
} else {
    // Return error message if ID parameter is not provided
    echo json_encode(array("message" => "ID parameter is missing."));
}

// Close database connection
$connect->close();
?>
