<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

include 'connection.php';

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}




// Get the search term from the query string
$searchTerm = isset($_GET['term']) ? $_GET['term'] : '';

// SQL query to search the database
$sql = "SELECT * FROM pejabat WHERE nama LIKE ?";
$stmt = $connect->prepare($sql);
$searchTermLike = "%$searchTerm%";
$stmt->bind_param("s", $searchTermLike);
$stmt->execute();
$result = $stmt->get_result();

// Fetch all results
$rows = array();
while($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($rows);

// Close connections
$stmt->close();
$connect->close();
