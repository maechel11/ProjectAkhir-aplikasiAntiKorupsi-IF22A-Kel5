<?php

include 'connection.php';

$sql = "SELECT * FROM tersangka_penyuapan";
$result = $connect->query($sql);

if (!$result) {
    die(json_encode(['error' => "Error in SQL query: " . $connect->error]));
}

$tersangka = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $tersangka[] = $row;
    }
} else {
    echo json_encode([]);
}
$connect->close();

echo json_encode($tersangka);
?>