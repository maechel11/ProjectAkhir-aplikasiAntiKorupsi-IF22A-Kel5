<?php 
include '../connection.php';
    $username = $_POST['text_username'];
    $email = $_POST['text_email'];
    $pass = $_POST['text_pass'];

    // isi query untuk cek data mahasiswa by npm
    $sql1 = "SELECT * FROM user WHERE username = '$username'";

    $check = $connect->query($sql1);
    $reason = "";
    $success = true;

    if($check->num_rows > 0) {
        $success = false;
        $reason = "username sudah ada";
    } else {
        //query untuk insert data
        $sql2 = "
        INSERT INTO
            user
        SET
            username = '$username',
            email =  '$email',
            pass = '$pass'   
        " ;

        $result = $connect->query($sql2);

        if(!$result){
            $success = false;
            $reason = "gagal Registrasi";
        }
    }
    echo json_encode(array(
        "success" => $success,
        "reason" => $reason,
    ));
?>