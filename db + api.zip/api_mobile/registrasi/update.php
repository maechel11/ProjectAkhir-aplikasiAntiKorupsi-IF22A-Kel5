<?php
include '../connection.php';

$id_user = $_POST['id_user'];
$username = $_POST['username'];
$email = $_POST['email'];
$current_password = $_POST['current_password'];
$new_password = $_POST['new_password'];
$confirm_password = $_POST['confirm_password'];

// Cek apakah bidang kata sandi lama dan kata sandi baru diisi
if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
    // Update dengan kata sandi baru
    $sql = "UPDATE user
            SET 
                username = '$username',
                email = '$email',
                pass = '$new_password'
            WHERE 
                id_user = '$id_user' AND pass = '$current_password'";
} else {
    // Jika tidak, hanya update nama pengguna dan email
    $sql = "UPDATE user
            SET 
                username = '$username',
                email = '$email'
            WHERE 
                id_user = '$id_user'";
}

$result = $connect->query($sql);

if ($result) {
    echo json_encode(array(
        "success" => true,
        "message" => "Profil berhasil diperbarui."
    ));
} else {
    echo json_encode(array(
        "success" => false,
        "message" => "Gagal memperbarui profil. Kata sandi lama mungkin tidak cocok atau terjadi kesalahan lain."
    ));
}
?>
