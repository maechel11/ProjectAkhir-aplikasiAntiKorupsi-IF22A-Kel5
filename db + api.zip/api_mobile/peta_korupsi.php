<?php

include 'connection.php';

$sql = "SELECT 
            COALESCE(provinsi.name, '') AS provinsi_name, 
            COALESCE(kota.name, '') AS kota_name, 
            COALESCE(pelaku.pelaku, '') AS pelaku_name
        FROM provinsi
        LEFT JOIN kota ON provinsi.id = kota.provinsi_id
        LEFT JOIN pelaku ON kota.id = pelaku.kota_id
        ORDER BY provinsi.name, kota.name";

$result = $connect->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);

$connect->close();
?>
