/*
SQLyog Ultimate v12.5.1 (64 bit)
MySQL - 10.4.28-MariaDB : Database - db_mobile
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_mobile` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;

USE `db_mobile`;

/*Table structure for table `berita` */

DROP TABLE IF EXISTS `berita`;

CREATE TABLE `berita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `isi` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `berita` */

insert  into `berita`(`id`,`judul`,`tanggal`,`imagePath`,`kategori`,`isi`) values 
(1,'Menggugah Kesadaran: Memahami Dampak dan Bahaya Korupsi','2024-05-28','../asset/images/Korupsi1.webp','kategori1','Korupsi, sebuah kata yang seringkali menyentak telinga dan menciptakan gelombang kemarahan di masyarakat. Dalam hakekatnya, korupsi merupakan tindakan yang merusak, memakan, dan menggerogoti fondasi moral sebuah bangsa. Dalam setiap level dan bidang kehidupan, korupsi mampu merusak tatanan sosial, menghambat perkembangan ekonomi, dan menghancurkan kepercayaan publik terhadap pemerintahan dan institusi. Di belahan dunia manapun, korupsi telah menjadi musuh utama keadilan, keberlanjutan, dan kesejahteraan.\r\n\r\nKorupsi bukanlah sekadar masalah hukum, tetapi juga masalah moral. Ketika para pemimpin dan pejabat yang seharusnya menjadi teladan malah terjerat dalam jaring laba pribadi, itu menciptakan lingkungan di mana keserakahan dianggap lebih penting daripada kepentingan publik. Korupsi menciptakan ketidaksetaraan yang mendalam dalam masyarakat, di mana mereka yang memiliki kekuasaan dan hubungan politik dapat menikmati keuntungan yang tidak adil, sementara orang biasa terpinggirkan dan tertindas.\r\n\r\nDampak korupsi tidak hanya terasa secara langsung, tetapi juga melalui berbagai aspek kehidupan. Dalam bidang ekonomi, korupsi menyebabkan alokasi sumber daya yang tidak efisien, menghambat investasi, dan merusak iklim bisnis. Dana yang seharusnya digunakan untuk pembangunan infrastruktur, pendidikan, dan kesehatan sering kali dialihkan untuk kepentingan pribadi, memperparah kesenjangan sosial dan menghambat pertumbuhan ekonomi yang inklusif.\r\n\r\nSelain itu, korupsi juga merusak sistem hukum dan keadilan. Ketika koruptor lolos dari hukuman atau bahkan menggunakan kekayaannya untuk membeli kebebasan, itu menciptakan ketidakpercayaan terhadap lembaga penegak hukum. Masyarakat yang melihat bahwa keadilan dapat dibeli dengan uang, kehilangan harapan pada sistem yang seharusnya melindungi mereka.\r\n\r\nKorupsi juga merupakan ancaman terhadap demokrasi. Ketika pemilihan dan proses politik dipengaruhi oleh uang dan kepentingan pribadi, suara rakyat menjadi terpinggirkan, dan representasi yang seharusnya merakyat pun terdistorsi. Politikus yang terpilih dengan cara yang tidak jujur cenderung melayani kepentingan kelompok kecil daripada kepentingan masyarakat secara keseluruhan.\r\n\r\nUntuk melawan korupsi, dibutuhkan komitmen kuat dari semua pihak. Pemerintah harus meningkatkan transparansi, akuntabilitas, dan penegakan hukum yang tegas terhadap pelaku korupsi. Masyarakat juga perlu dilibatkan dalam proses pengawasan dan pemantauan, sehingga koruptor tidak dapat bersembunyi di balik tirai kegelapan.\r\n\r\nPendidikan juga memainkan peran penting dalam pencegahan korupsi. Dengan membangun kesadaran akan bahaya dan dampak negatif korupsi sejak dini, generasi masa depan dapat menjadi garda terdepan dalam memerangi praktik korupsi.\r\n\r\nKorupsi bukanlah masalah yang dapat diselesaikan dalam semalam, tetapi dengan komitmen bersama dan tindakan nyata, kita dapat membangun masyarakat yang lebih adil, berintegritas, dan sejahtera. Saatnya bagi kita semua untuk berdiri bersama melawan korupsi, untuk mewujudkan masa depan yang lebih baik bagi semua orang.'),
(2,'Korupsi Timah Rp 271 T dan Momentum Pembenahan Sektor SDA','2024-05-28','../asset/images/Korupsi2.jpeg','kategori2','Kasus mega korupsi yang baru-baru ini menggemparkan Indonesia, khususnya dalam konteks tata niaga komoditas timah oleh PT Timah Tbk, memunculkan pertanyaan serius mengenai dampaknya terhadap keuangan negara. Diperkirakan kerugian keuangan negara mencapai angka yang sangat besar, mencapai Rp 271 triliun, yang merupakan jumlah yang sangat fantastis dan mengejutkan bagi masyarakat Indonesia.\r\n\r\nUntuk memahami bagaimana penghitungan kerugian keuangan negara dilakukan dalam kasus seperti ini, perlu pemahaman yang baik tentang apa yang dimaksud dengan keuangan negara dan kerugian negara menurut hukum Indonesia. Undang-Undang Nomor 17 Tahun 2003 tentang Keuangan Negara mendefinisikan keuangan negara sebagai semua hak dan kewajiban negara yang dapat dinilai dengan uang, serta segala sesuatu baik berupa uang maupun berupa barang yang dapat dijadikan milik negara. Sementara itu, kerugian negara menurut Undang-Undang Nomor 1 Tahun 2004 tentang Perbendaharaan Negara adalah kekurangan uang surat berharga, dan barang, yang nyata dan pasti jumlahnya sebagai akibat perbuatan melawan hukum, baik sengaja maupun lalai.\r\n\r\nDalam kasus ini, besarnya kerugian keuangan negara telah dihitung dengan mempertimbangkan berbagai aspek, terutama kerugian lingkungan hidup yang diakibatkan oleh praktik ilegal dalam tata niaga komoditas timah oleh PT Timah Tbk. Penghitungan ini dilakukan sesuai dengan Peraturan Menteri Lingkungan Hidup dan Kehutanan No. 7 Tahun 2014 tentang Kerugian Lingkungan Hidup akibat Pencemaran dan/atau Kerusakan Lingkungan Hidup.\r\n\r\nMenurut Ahli yang dihadirkan dari Penyidik, yaitu akademisi dari Fakultas Kehutanan dan Lingkungan IPB, Bambang Hero Saharjo, kerugian keuangan negara dalam kasus ini mencakup beberapa aspek. Pertama, kerugian lingkungan (ekologis) sebesar Rp 157 triliun, yang mencakup biaya untuk menghidupkan kembali fungsi tata air, pengaturan tata air, pengendalian erosi dan limpasan, pembentukan tanah, pendaur ulang unsur hara, fungsi pengurai limbah, biodiversitas (keanekaragaman hayati), sumber daya genetik, dan pelepasan karbon. Kedua, kerugian ekonomi lingkungan sebesar Rp 60 triliun, yang mencakup biaya ekonomi yang hilang akibat kerusakan lingkungan tersebut. Ketiga, biaya pemulihan lingkungan sebesar Rp 5 triliun untuk memulihkan kerusakan yang telah terjadi. Selain itu, ada juga kerugian di luar kawasan hutan sekitar sebesar Rp 47 triliun.\r\n\r\nDengan demikian, total kerugian keuangan negara dalam kasus ini mencapai Rp 271 triliun, yang merupakan jumlah yang sangat besar dan memberikan gambaran tentang dampak serius dari praktik korupsi terhadap keuangan negara dan lingkungan hidup. Kasus ini juga menambah daftar kasus mega korupsi sebelumnya di Indonesia, seperti kasus Bantuan Likuiditas Bank Indonesia (BLBI), penyerobotan lahan negara untuk kelapa sawit, pengelolaan dana pensiun PT Asabri, dan penyimpangan dana investasi PT Asuransi Angkatan Bersenjata Republik Indonesia (Asabri).\r\n\r\nDari kasus-kasus tersebut, dapat dilihat bahwa korupsi bukan hanya merupakan masalah hukum, tetapi juga masalah sosial, ekonomi, dan lingkungan yang sangat serius. Oleh karena itu, penegakan hukum yang tegas, transparansi, akuntabilitas, serta partisipasi aktif dari masyarakat dalam pengawasan terhadap pengelolaan keuangan negara menjadi sangat penting dalam upaya pemberantasan korupsi dan perlindungan keuangan negara serta lingkungan hidup di Indonesia.'),
(3,'Ketua KPK Ungkap 26 Provinsi Terlibat Korupsi, Jabar Paling Banyak','2024-05-28','../asset/images/Korupsi3.jpeg','kategori3','Dalam konteks pemberantasan korupsi di Indonesia, data yang diungkapkan oleh Ketua Komisi Pemberantasan Korupsi (KPK) Komjen Firli Bahuri menjadi sorotan penting. Dalam sebuah webinar dengan para calon kepala daerah, Firli Bahuri memaparkan bahwa dari 34 provinsi di Indonesia, sebanyak 26 provinsi telah mengalami tindak pidana korupsi sejak periode 2004 hingga 2020. Hal ini merupakan sebuah tantangan yang signifikan bagi upaya pemberantasan korupsi di negara ini.\r\n\r\nPenting untuk dicatat bahwa korupsi merupakan masalah yang merugikan bagi pembangunan dan kemajuan suatu negara. Selain menyebabkan kerugian finansial yang besar, korupsi juga merusak kepercayaan masyarakat terhadap pemerintah dan lembaga-lembaga publik. Oleh karena itu, upaya pemberantasan korupsi merupakan sebuah prioritas bagi pemerintah dan lembaga anti-korupsi seperti KPK.\r\n\r\nMenurut data yang diungkapkan oleh Firli Bahuri, provinsi-provinsi di Indonesia, terutama di Pulau Jawa dan Sumatera, menjadi daerah yang rentan terhadap tindak pidana korupsi. Dari 26 provinsi yang mengalami korupsi, Jawa Barat menduduki peringkat teratas dengan 101 kasus, disusul oleh Jawa Timur dengan 93 kasus, dan Sumatera Utara dengan 73 kasus. Hal ini menunjukkan bahwa tindak pidana korupsi tidak hanya terbatas pada wilayah tertentu, namun menyebar di berbagai daerah di Indonesia.\r\n\r\nPerlu dipahami bahwa pemberantasan korupsi bukanlah hal yang mudah dilakukan. Dibutuhkan kerja keras, komitmen yang kuat, serta kerjasama dari berbagai pihak, termasuk pemerintah, lembaga anti-korupsi, masyarakat, dan sektor swasta. Langkah-langkah konkret seperti penegakan hukum yang tegas terhadap pelaku korupsi, peningkatan transparansi dan akuntabilitas dalam pengelolaan keuangan publik, serta penguatan sistem pengawasan dan kontrol menjadi beberapa strategi yang dapat dilakukan untuk mengatasi masalah korupsi.\r\n\r\nSelain itu, penting juga untuk meningkatkan kesadaran akan bahaya korupsi di kalangan masyarakat. Pendidikan tentang pentingnya integritas, etika, dan moralitas dalam kehidupan berbangsa dan bernegara harus ditanamkan sejak dini. Masyarakat juga perlu dilibatkan secara aktif dalam pengawasan terhadap penggunaan anggaran publik dan dalam melaporkan tindak pidana korupsi yang terjadi di sekitar mereka.\r\n\r\nPada akhirnya, pemberantasan korupsi merupakan sebuah perjuangan yang memerlukan waktu dan kesabaran. Namun, dengan komitmen yang kuat dan kerjasama semua pihak, diharapkan Indonesia dapat mengatasi masalah korupsi dan menuju pada tatanan pemerintahan yang lebih bersih, transparan, dan akuntabel. Semua pihak, baik pemerintah maupun masyarakat, memiliki peran penting dalam upaya ini demi terwujudnya sebuah negara yang adil dan sejahtera.'),
(4,'Korupsi Rp 43 Miliar Proyek Bendungan di Lampung, 4 Jadi Tersangka','2024-05-28','../asset/images/Korupsi4.jpeg','kategori4','Kasus dugaan korupsi proyek nasional Bendungan Marga Tiga di Lampung Timur menjadi sorotan karena potensi kerugian yang sangat besar bagi negara. Dengan perkiraan kerugian mencapai Rp 43 miliar dan potensi kehilangan yang bahkan mencapai Rp 439,5 miliar, kasus ini menunjukkan dampak yang serius dari praktik korupsi terhadap pembangunan dan keuangan negara.\r\n\r\nKepolisian Daerah Lampung telah mengambil langkah tegas dengan menetapkan empat tersangka dalam kasus ini setelah melakukan pemeriksaan terhadap 200 orang saksi dan 10 orang saksi ahli. Tindakan ini menunjukkan komitmen dari aparat penegak hukum dalam mengungkap dan menindak tindak korupsi yang merugikan negara.\r\n\r\nKeempat tersangka yang telah ditetapkan termasuk mantan kepala Badan Pertanahan Nasional (BPN) Lampung Timur periode 2020-2022, serta beberapa individu lain yang terlibat dalam pelaksanaan proyek, seperti mantan Kepala Desa Trimulyo dan anggota satuan tugas proyek tersebut. Selain menetapkan tersangka, penyidik juga berhasil mengamankan barang bukti berupa uang senilai Rp 9,35 miliar, ponsel, komputer jinjing, dan SIM card. Dokumen-dokumen terkait pengadaan tanah dan pengerjaan proyek juga turut diamankan dalam proses penyidikan.\r\n\r\nProses penyidikan ini tidak hanya bertujuan untuk mengungkap tindak pidana korupsi, tetapi juga untuk menyelamatkan keuangan negara dari potensi kerugian yang lebih besar. Melalui hasil audit yang dilakukan oleh Pemerintah, ratusan miliar rupiah uang negara berhasil diselamatkan dari potensi penyalahgunaan dalam proyek ini. Audit tersebut mengungkapkan adanya pembayaran ganti-kerugian untuk 202 lahan, serta 1.744 bidang lainnya yang masih dalam proses pembebasan lahan.\r\n\r\nPenting untuk dicatat bahwa kasus korupsi ini tidak terkait langsung dengan pembangunan fisik bendungan, tetapi lebih pada proses pembebasan lahan yang merupakan tahap awal dari proyek tersebut. Hal ini menunjukkan kompleksitas dari praktik korupsi dalam berbagai tahapan pembangunan proyek, dimulai dari pengadaan tanah hingga pelaksanaan fisik.\r\n\r\nLangkah-langkah yang telah diambil oleh Kepolisian Daerah Lampung dalam mengungkap kasus ini merupakan langkah yang sangat positif dalam upaya pemberantasan korupsi di Indonesia. Namun, perlu juga adanya langkah-langkah preventif dan penguatan sistem pengawasan yang lebih baik untuk mencegah terjadinya korupsi di masa mendatang. Transparansi, akuntabilitas, dan partisipasi masyarakat yang lebih aktif juga menjadi kunci dalam upaya menciptakan lingkungan yang bebas dari korupsi dan memastikan penggunaan anggaran negara yang efektif dan efisien demi kesejahteraan masyarakat.'),
(5,'Ada Dugaan Kasus Korupsi di Anak Usaha, Begini Penjelasan Telkom (TLKM)','2024-05-28','../asset/images/Korupsi5.jpeg','kategori5','PT Telkom Indonesia Tbk (TLKM) menghadapi tantangan serius dalam mengatasi dugaan kasus korupsi yang melibatkan anak perusahaan mereka, PT Sigma Cipta Caraka. VP Corporate Communication Telkom, Andri Herawan Sasoko, memberikan penjelasan terkait proses hukum yang sedang berlangsung di Komisi Pemberantasan Korupsi (KPK) terkait kasus ini.\r\n\r\nAndri menjelaskan bahwa kasus ini merupakan hasil dari temuan Audit Investigasi Telkom, yang merupakan bagian dari upaya perusahaan dalam menerapkan prinsip-prinsip tata kelola perusahaan yang baik (good corporate governance/GCG). Telkom Indonesia Tbk, sebagai perusahaan induk dari PT Sigma Cipta Caraka, mendukung dan menghormati proses hukum yang sedang berlangsung, serta telah menyampaikan hasil audit internal dan bukti-bukti yang diperlukan kepada Penyidik KPK.\r\n\r\nSaat ini, perkara tersebut sedang dalam tahap penyidikan oleh KPK, dan Telkom terus memberikan dukungan dalam kapasitasnya sebagai perusahaan induk. Namun, Andri juga menegaskan bahwa belum ada informasi yang dapat disampaikan terkait fakta atau kejadian penting lainnya yang dapat mempengaruhi harga efek perseroan serta kelangsungan hidup Perseroan yang belum diungkapkan kepada publik.\r\n\r\nDugaan korupsi ini menimbulkan dampak serius bagi reputasi Telkom Indonesia Tbk, terutama dalam hal kepercayaan dari para pemegang saham dan publik secara umum. Isu kasus dugaan korupsi pengadaan barang dan jasa fiktif dengan kerugian mencapai ratusan miliar rupiah telah mengarahkan perhatian pada integritas dan transparansi dalam praktik bisnis perusahaan.\r\n\r\nKasus ini juga menunjukkan pentingnya perusahaan dalam menjalankan prinsip-prinsip GCG secara konsisten dan komprehensif. Praktik-praktik yang terbuka, transparan, dan akuntabel menjadi kunci dalam membangun kepercayaan stakeholder dan menjaga reputasi perusahaan. Langkah-langkah penegakan hukum yang tegas dari pihak berwenang juga diperlukan untuk memastikan pertanggungjawaban atas tindakan korupsi serta mencegahnya terjadi di masa mendatang.\r\n\r\nBagi TLKM, proses ini juga merupakan kesempatan untuk memperbaiki sistem internal, memperkuat pengawasan, dan meningkatkan ketaatan terhadap aturan dan prosedur yang berlaku. Selain itu, komitmen untuk bekerja sama dengan pihak berwenang dalam proses penyelidikan dan penegakan hukum harus dipertahankan untuk memastikan bahwa kebenaran dan keadilan tercapai.\r\n\r\nDalam konteks ini, transparansi dan komunikasi yang efektif kepada publik menjadi penting untuk menjelaskan langkah-langkah yang diambil perusahaan dalam menangani kasus ini, serta memberikan keyakinan bahwa Telkom Indonesia Tbk tetap berkomitmen untuk beroperasi dengan standar integritas yang tinggi.');

/*Table structure for table `faq` */

DROP TABLE IF EXISTS `faq`;

CREATE TABLE `faq` (
  `pertanyaan` text DEFAULT NULL,
  `jawaban` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `faq` */

insert  into `faq`(`pertanyaan`,`jawaban`) values 
('sdasdasd','sdasdasd'),
('sdasd afg','sdasdasdsad');

/*Table structure for table `instansi_korupsi` */

DROP TABLE IF EXISTS `instansi_korupsi`;

CREATE TABLE `instansi_korupsi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_instansi` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `tahun_korupsi` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `instansi_korupsi` */

insert  into `instansi_korupsi`(`id`,`nama_instansi`,`keterangan`,`lokasi`,`tahun_korupsi`) values 
(1,'Instansi A','Deskripsi Instansi A','Lokasi A',2020),
(2,'Instansi B','Deskripsi Instansi B','Lokasi B',2019),
(3,'Instansi C','Deskripsi Instansi C','Lokasi C',2021),
(4,'Instansi D','Deskripsi Instansi D','Lokasi D',2018);

/*Table structure for table `kota` */

DROP TABLE IF EXISTS `kota`;

CREATE TABLE `kota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `provinsi_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provinsi_id` (`provinsi_id`),
  CONSTRAINT `kota_ibfk_1` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsi` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `kota` */

insert  into `kota`(`id`,`name`,`provinsi_id`) values 
(1,'Jumlah Kasus',1),
(2,'Jumlah Kasus',2),
(3,'Jumlah Kasus',3),
(4,'Jumlah Kasus',4),
(5,'Jumlah Kasus',5),
(6,'Jumlah Kasus',6),
(7,'Jumlah Kasus',7),
(8,'Jumlah Kasus',8),
(9,'Jumlah Kasus',9),
(10,'Jumlah Kasus',10),
(11,'Jumlah Kasus',11),
(12,'Jumlah Kasus',12),
(13,'Jumlah Kasus',13),
(14,'Jumlah Kasus',14),
(15,'Jumlah Kasus',15),
(16,'Jumlah Kasus',16),
(17,'Jumlah Kasus',17),
(18,'Jumlah Kasus',18),
(19,'Jumlah Kasus',19),
(20,'Jumlah Kasus',20),
(21,'Jumlah Kasus',21),
(22,'Jumlah Kasus',22),
(23,'Jumlah Kasus',23),
(24,'Jumlah Kasus',24),
(25,'Jumlah Kasus',25),
(26,'Jumlah Kasus',26),
(27,'Jumlah Kasus',27),
(28,'Jumlah Kasus',28),
(29,'Jumlah Kasus',29),
(30,'Jumlah Kasus',30),
(31,'Jumlah Kasus',31),
(32,'Jumlah Kasus',32),
(33,'Jumlah Kasus',33),
(34,'Jumlah Kasus',34),
(35,'Jumlah Kasus',33),
(36,'Jumlah Kasus',33),
(37,'Jumlah Kasus',33),
(38,'Jumlah Kasus',33),
(39,'Labuhanbatu',33),
(40,'Labuhanbatu Selatan',33),
(41,'Labuhanbatu Utara',33);

/*Table structure for table `pejabat` */

DROP TABLE IF EXISTS `pejabat`;

CREATE TABLE `pejabat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `kasus` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `pejabat` */

insert  into `pejabat`(`id`,`nama`,`jabatan`,`kasus`,`foto`) values 
(1,'Rokhmin Dahuri','mantan Menteri Kelautan dan Perikanan era Presiden kelima Megawati Soekarnoputri','terbukti secara sah melakukan tindak pidana korupsi dalam dana nonbudgeter di Departemen Kelautan dan Perikanan senilai Rp 31,7 miliar.','../asset/images/rokmin.jpg'),
(2,'Achmad Sujudi','Menteri Kesehatan era Megawati','kasus korupsi pengadaan alat kesehatan di Departemen Kesehatan.','../asset/images/sujudi.jpg'),
(3,'Hari Sabarno','mantan Menteri Dalam Negeri','terbukti melakukan pidana korupsi dengan penunjukan langsung PT Satal Nusantara dan PT Istana Saranaraya milik Hengky Samuel Daud (almarhum) sebagai perusahaan yang ditunjuk dalam pengadaan 208 mobil damkar di 22 wilayah seluruh Indonesia pada 2003 hingga','../asset/images/rokmin.jpg'),
(4,'Bachtiar Chamsyah','mantan Menteri Sosial era Presiden Megawati dan Susilo Bambang Yudhoyono.','erbukti melakukan korupsi dengan menyetujui penunjukan langsung pengadaan mesin jahit, sapi impor, dan kain sarung yang merugikan negara hingga Rp 33,7 miliar.','../asset/images/sujudi.jpg'),
(5,'Siti Fadilah Supari','Mantan Menteri Kesehatan era SBY','terbukti menyalahgunaan wewenang dalam kegiatan pengadaan alat kesehatan (alkes) guna mengantisipasi kejadian luar biasa (KLB) tahun 2005, pada Pusat Penanggulangan Masalah Kesehatan (PPMK) Departemen Kesehatan.','../asset/images/rokmin.jpg'),
(6,'Andi Mallarangeng','mantan Menteri Pemuda dan Olahraga (Menpora) era SBY','terjerat kasus korupsi terkait proyek pembangunan Pusat Pendidikan, Pelatihan, Sekolah Olahraga Nasional (P3SON) Hambalang sebagaimana dakwaan alternatif kedua. tas perbuatannya, Andi dinilai telah merugikan keuangan negara sebesar Rp 463,391 miliar','../asset/images/sujudi.jpg'),
(7,'Jero Wacik','antan Menteri Energi dan Sumber Daya Mineral (ESDM) dan Menteri Kebudayaan dan Pariwisata.','terseret kasus korupsi penyalahgunaan dana operasional selama menjabat sebagai menteri di dua lembaga itu','../asset/images/rokmin.jpg');

/*Table structure for table `pelaku` */

DROP TABLE IF EXISTS `pelaku`;

CREATE TABLE `pelaku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pelaku` varchar(255) NOT NULL,
  `kota_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kota_id` (`kota_id`),
  CONSTRAINT `pelaku_ibfk_1` FOREIGN KEY (`kota_id`) REFERENCES `kota` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `pelaku` */

insert  into `pelaku`(`id`,`pelaku`,`kota_id`) values 
(1,'482 Kasus',1),
(2,'15 Kasus',2),
(3,'84 Kasus',3),
(4,'59 Kasus',4),
(5,'3 Kasus',5),
(6,'24 Kasus',6),
(7,'7 Kasus',7),
(8,'70 Kasus',8),
(9,'22 Kasus',9),
(10,'0 Kasus',10),
(11,'70 Kasus',11),
(12,'27 Kasus',12),
(13,'142 Kasus',13),
(14,'69 Kasus',14),
(15,'6 Kasus',15),
(16,'9 Kasus',16),
(17,'8 Kasus',17),
(18,'36 Kasus',18),
(19,'16 Kasus',19),
(20,'7 Kasus',20),
(21,'10 Kasus',21),
(22,'45 Kasus',22),
(23,'0 Kasus',23),
(24,'11 Kasus',24),
(25,'12 Kasus',25),
(26,'14 Kasus',26),
(27,'21 Kasus',27),
(28,'0 Kasus',28),
(29,'15 Kasus',29),
(30,'9 Kasus',30),
(31,'15 Kasus',31),
(32,'11 Kasus',32),
(33,'41 Kasus',33),
(34,'8 Kasus',34),
(35,'0 Kasus',35),
(36,'0 Kasus',36),
(37,'0 Kasus',37),
(38,'0 Kasus',38),
(39,'0 Kasus',39);

/*Table structure for table `provinsi` */

DROP TABLE IF EXISTS `provinsi`;

CREATE TABLE `provinsi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `provinsi` */

insert  into `provinsi`(`id`,`name`) values 
(1,'Pemerintah Pusat'),
(2,'Nanggroe Aceh Darussalam'),
(3,'Sumatera Utara'),
(4,'Sumatera Selatan'),
(5,'Sumatera Barat'),
(6,'Jambi'),
(7,'Kepulauan Riau'),
(8,'Riau'),
(9,'Bengkulu'),
(10,'Kepulauan Bangka Belitung'),
(11,'DKI Jakarta'),
(12,'Banten'),
(13,'Jawa Barat'),
(14,'Jawa Tengah'),
(15,'Jawa Timur'),
(16,'DIY Yogyakarta'),
(17,'Bali'),
(18,'Lampung'),
(19,'Kalimantan Selatan'),
(20,'Kalimantan Tengah'),
(21,'Kalimantan Barat'),
(22,'Kalimantan Timur'),
(23,'Kalimantan Utara'),
(24,'Sulawesi Utara '),
(25,'Sulawesi Selatan'),
(26,'Sulawesi Tengah'),
(27,'Sulawesi Tenggara'),
(28,'Gorontalo'),
(29,'Maluku '),
(30,'Maluku Utara'),
(31,'Nusa Tenggara Barat'),
(32,'Nusa Tenggara Timut'),
(33,'Papua'),
(34,'Papua Barat'),
(35,'Papua Tengah'),
(36,'Papua Pegunungan'),
(37,'Papua Selatan'),
(38,'Papua Barat Daya'),
(39,'Sulawesi Barat');

/*Table structure for table `reports` */

DROP TABLE IF EXISTS `reports`;

CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `accused_name` varchar(255) NOT NULL,
  `accused_address` varchar(255) NOT NULL,
  `report_description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `reports` */

insert  into `reports`(`id`,`NAME`,`phone`,`email`,`accused_name`,`accused_address`,`report_description`,`created_at`) values 
(2,'a','a','a@a','a','a','a','2024-06-03 22:47:21'),
(3,'b','b','b@b','b','b','b','2024-06-03 22:47:38');

/*Table structure for table `tentangkami` */

DROP TABLE IF EXISTS `tentangkami`;

CREATE TABLE `tentangkami` (
  `judul` text DEFAULT NULL,
  `jawaban` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `tentangkami` */

insert  into `tentangkami`(`judul`,`jawaban`) values 
('asdasfgqwg','sdasdqaw');

/*Table structure for table `uud` */

DROP TABLE IF EXISTS `uud`;

CREATE TABLE `uud` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `full_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `uud` */

insert  into `uud`(`id`,`title`,`short_description`,`full_description`) values 
(1,'UU No. 31 Tahun 1999','Pemberantasan Tindak Pidana Korupsi.','UU No. 31 Tahun 1999 tentang Pemberantasan Tindak Pidana Korupsi mengatur berbagai aspek pencegahan dan penindakan tindak pidana korupsi, termasuk sanksi dan hukuman bagi pelaku korupsi.'),
(2,'UU No. 20 Tahun 2001','Perubahan atas UU No. 31 Tahun 1999.','UU No. 20 Tahun 2001 tentang Perubahan atas UU No. 31 Tahun 1999 memperbarui dan menyempurnakan ketentuan sebelumnya terkait pemberantasan tindak pidana korupsi, dengan penambahan beberapa pasal penting untuk efektivitas hukum.'),
(3,'UU No. 30 Tahun 2002','Komisi Pemberantasan Tindak Pidana Korupsi (KPK).','UU No. 30 Tahun 2002 membentuk Komisi Pemberantasan Korupsi (KPK) sebagai lembaga independen yang bertugas untuk mengkoordinasikan dan mengawasi upaya pemberantasan tindak pidana korupsi di Indonesia.');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
