<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
include 'connection.php';

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
} 

// Check connection
if ($connect->connect_error) {
    die(json_encode(array("error" => "Connection failed: " . $connect->connect_error)));
}

$sql = "SELECT * FROM reports";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    $reports = array();
    while($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
    echo json_encode($reports);
} else {
    echo json_encode(array());
}

$connect->close();
?>
