<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');

include 'connection.php';

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

$sql = "SELECT imagePath, judul, tanggal, kategori, isi FROM berita";
$result = $connect->query($sql);

$berita = array();

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $berita[] = $row;
    }
} else {
    echo json_encode([]);
}
$connect->close();

echo json_encode($berita);
?>
